import sys
py3k = sys.version_info >= (3, 0)
