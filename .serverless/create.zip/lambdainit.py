"""Special initializations for Lambda."""

import sys


try:
  import unzip_requirements
except ImportError:
  pass
# add packaged dependencies to search path
sys.path.append('lib')
