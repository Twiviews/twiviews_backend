# -*- coding: utf-8 -*-
# - Copyright (c) 2016-, jupyter-contrib development team

"""Core functionality for jupyter-contrib projects."""

from __future__ import unicode_literals

__version__ = '0.3.3'
